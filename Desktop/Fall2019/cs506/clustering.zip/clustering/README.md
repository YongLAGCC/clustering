# clustering

[![Build Status](https://travis-ci.org/gallettilance/clustering.svg?branch=master)](https://travis-ci.org/gallettilance/clustering)

this is an example package for clustering implementations learned in BU CS506